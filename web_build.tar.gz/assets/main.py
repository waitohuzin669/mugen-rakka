import pygame
import random
import sys
import os
import json
import asyncio
import urllib.request
import urllib.parse
import threading
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

GAS_URL ="https://script.google.com/macros/s/AKfycbxhPJq5erKXDTkEVkOFwGsMsmBp-QEDpPCKl-j4Q11mmx6Z5FgEzZZzlgObDFKa-w/exec"
online_ranking_data = None

def _fetch_ranking_sync():
    global online_ranking_data
    try:
        url = f"{GAS_URL}?action=get"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as res:
            online_ranking_data = json.loads(res.read().decode('utf-8'))
    except Exception as e:
        print("Fetch Ranking Error:", e)

def _save_score_sync(name, score):
    global online_ranking_data
    try:
        query = urllib.parse.urlencode({'action': 'save', 'name': name, 'score': score})
        url = f"{GAS_URL}?{query}"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as res:
            online_ranking_data = json.loads(res.read().decode('utf-8'))
    except Exception as e:
        print("Save Score Error:", e)

async def fetch_ranking():
    global online_ranking_data
    if sys.platform == "emscripten":
        try:
            # Web用: ネイティブのJavaScriptを使ってフェッチし、CORSやリダイレクト問題を完全回避する
            import platform
            import asyncio
            window = platform.window
            
            # JS側でデータを取得し、グローバル変数に文字列として格納する
            js_code = f"""
            window._ranking_temp = null;
            fetch('{GAS_URL}?action=get')
                .then(r => r.text())
                .then(t => window._ranking_temp = t)
                .catch(e => window._ranking_temp = 'ERROR');
            """
            window.eval(js_code)
            
            # JS側での取得完了を待つ (最大5秒)
            for _ in range(50):
                await asyncio.sleep(0.1)
                data = getattr(window, '_ranking_temp', None)
                if data is not None and str(data) != "null":
                    if str(data) != 'ERROR':
                        online_ranking_data = json.loads(str(data))
                    break
        except Exception as e:
            print("Web Fetch Error:", e)
    else:
        # PC用: スレッドで非同期化
        import threading
        threading.Thread(target=_fetch_ranking_sync, daemon=True).start()

async def save_score(name, score):
    global online_ranking_data
    if sys.platform == "emscripten":
        try:
            import platform
            window = platform.window
            query = urllib.parse.urlencode({'action': 'save', 'name': name, 'score': score})
            js_code = f"""
            fetch('{GAS_URL}?{query}')
                .then(r => r.text())
                .then(t => window._ranking_temp = t)
                .catch(e => window._ranking_temp = 'ERROR');
            """
            window.eval(js_code)
            
            import asyncio
            for _ in range(50):
                await asyncio.sleep(0.1)
                data = getattr(window, '_ranking_temp', None)
                if data is not None and str(data) != "null":
                    if str(data) != 'ERROR':
                        online_ranking_data = json.loads(str(data))
                    break
        except Exception as e:
            print("Web Save Error:", e)
    else:
        import threading
        threading.Thread(target=_save_score_sync, args=(name, score), daemon=True).start()

class DropManGame:
    def __init__(self):
        pygame.init()
        # 実際のウィンドウサイズ
        self.WINDOW_W = 600
        self.WINDOW_H = 800
        self.screen = pygame.display.set_mode((self.WINDOW_W, self.WINDOW_H))
        pygame.display.set_caption("無限落下")
        self.clock = pygame.time.Clock()

        # 内部の解像度（ガラケー仕様のQVGAサイズ）
        self.WIDTH = 240
        self.HEIGHT = 320
        # 描画用Surfaceのみ2倍の解像度にする
        self.display = pygame.Surface((self.WIDTH * 2, self.HEIGHT * 2))

        # 色 (レトロ ハイコントラスト)
        self.WHITE = (252, 252, 252) # ピュアな白
        self.BLACK = (  0,   0,   0) # 真っ黒
        self.GREEN = (136, 228,   0) # 普通の緑（土管の緑）
        self.RED = (248, 56, 0)      # 普通の赤（マリオの赤）
        self.CYAN = ( 40, 120, 248)  # 普通の青色

        # プレイヤー設定 (解像度に合わせて縮小)
        self.player_w = 16
        self.player_h = 16
        self.gravity = 0.1      # 重力 (数値を大きくすると落下スピードが上がる)
        self.move_speed = 2.5   # 左右の移動速度 (数値を大きくすると速く動ける)

        # プラットフォーム設定
        self.PLAT_H = 8

        # 画像読み込み
        self.img_stand = self.load_img("player_stand.png")
        self.img_left = self.load_img("player_right.png")
        self.img_right = self.load_img("player_left.png")
        self.img_fall = self.load_img("player_fall.png")

        # ブロック画像読み込み
        self.img_blocks = {
            "normal": self.load_block_img("blocks_normal.png"),
            "spike": self.load_block_img("blocks_spike.png"),
            "fragile": self.load_block_img("blocks_broken.png"),
            "trampoline": self.load_block_img("blocks_spring.png"),
            "conveyor_right": self.load_block_img("blocks_right.png"),
            "conveyor_left": self.load_block_img("blocks_left.png"),
        }

        # 効果音読み込み
        try:
            self.snd_land = pygame.mixer.Sound(os.path.join(BASE_DIR, "assets", "land.ogg"))
            self.snd_land.set_volume(0.15)
            self.snd_bounce = pygame.mixer.Sound(os.path.join(BASE_DIR, "assets", "bounce.ogg"))
            self.snd_bounce.set_volume(0.2)
            self.snd_gameover = pygame.mixer.Sound(os.path.join(BASE_DIR, "assets", "gameover.ogg"))
            self.snd_gameover.set_volume(0.3)
        except Exception as e:
            print(f"Error loading sounds: {e}")
            self.snd_land = self.snd_bounce = self.snd_gameover = None

        # フォント読み込み (小さくする)
        font_path = os.path.join(BASE_DIR, "assets", "font.ttf")
        try:
            self.font = pygame.font.Font(font_path, 28)
            self.big_font = pygame.font.Font(font_path, 42)
        except Exception as e:
            print(f"Error loading font: {e}")
            self.font = pygame.font.SysFont(None, 28)
            self.big_font = pygame.font.SysFont(None, 42)

        self.menu_options = ["スタート", "ランキング"]
        self.menu_index = 0

        self.game_state = "START"
        self.on_ground = False
        self.game_state = "START"
        asyncio.create_task(fetch_ranking())

    def load_img(self, name):
        path = os.path.join(BASE_DIR, "assets", name)
        try:
            img = pygame.image.load(path).convert_alpha()
            return pygame.transform.scale(img, (self.player_w * 2, self.player_h * 2))
        except Exception as e:
            print(f"Error loading {name} from {path}: {e}")
            surf = pygame.Surface((self.player_w * 2, self.player_h * 2))
            surf.fill(self.WHITE)
            return surf

    def load_block_img(self, name):
        path = os.path.join(BASE_DIR, "assets", name)
        try:
            return pygame.image.load(path).convert_alpha()
        except Exception as e:
            print(f"Error loading {name} from {path}: {e}")
            surf = pygame.Surface((16, 16))
            surf.fill(self.WHITE)
            return surf

    def reset_game(self):
        self.player_x = self.WIDTH // 2
        self.player_y = 120
        self.player_vy = 0
        self.player_vx = 0
        self.platforms = []
        self.scroll_speed = 0.75
        self.score = 0
        self.max_fall_distance = 0
        self.current_fall_distance = 0
        self.game_state = "PLAY"
        
        # 初期プラットフォーム
        self.platforms.append({
            "rect": pygame.Rect(self.WIDTH//2 - 24, 150, 48, self.PLAT_H),
            "type": "normal",
            "vx": 0,
            "exact_x": float(self.WIDTH//2 - 24),
            "exact_y": float(150)
        })
        for i in range(13):
            self.spawn_platform(180 + i * 20)

    def spawn_platform(self, y):
        # 横幅も8の倍数に戻す (24〜56)
        w = random.randint(3, 7) * self.PLAT_H
        x = random.randint(0, self.WIDTH - w)
        
        r = random.random()
        p_type = "normal"
        vx = 0
        if getattr(self, 'score', 0) >= 800:
            # === スコア800m以降のブロック出現率 (ギミック超多め) ===
            if r < 0.35:
                p_type = "moving"     # 35%の確率で「動く足場」
                vx = random.choice([-1.5, -1, 1, 1.5])
            elif r < 0.55:
                p_type = "trampoline" # 20% (0.55 - 0.35) の確率で「バネ」
            elif r < 0.75:
                p_type = "fragile"    # 20% (0.75 - 0.55) の確率で「ヒビ」
            elif r < 0.80:
                p_type = "spike"      # 5% (0.80 - 0.75) の確率で「トゲ」(変化なし)
            elif r < 0.95:
                p_type = "conveyor"   # 15% (0.95 - 0.80) の確率で「コンベア」
                vx = random.choice([-1.0, 1.0])
            # 残りの 5% (1.00 - 0.95) のみが「通常の青ブロック」になります
        elif getattr(self, 'score', 0) >= 400:
            # === スコア400m以降のブロック出現率 (ギミック多め) ===
            # r は 0.0〜1.0 のランダムな値。これを使って確率を分けます。
            if r < 0.25:
                p_type = "moving"     # 25%の確率で「動く足場」
                vx = random.choice([-1.5, -1, 1, 1.5])
            elif r < 0.40:
                p_type = "trampoline" # 15% (0.40 - 0.25) の確率で「バネ」
            elif r < 0.65:
                p_type = "fragile"    # 25% (0.65 - 0.40) の確率で「ヒビ」
            elif r < 0.70:
                p_type = "spike"      # 5% (0.70 - 0.65) の確率で「トゲ」(変化なし)
            elif r < 0.85:
                p_type = "conveyor"   # 15% (0.85 - 0.70) の確率で「コンベア」
                vx = random.choice([-1.0, 1.0])
            # 残りの 15% (1.00 - 0.85) は「通常の青ブロック」になります
        else:
            # === スコア400m未満のブロック出現率 (通常通り) ===
            if r < 0.15:
                p_type = "moving"     # 15%の確率で「動く足場」
                vx = random.choice([-1.5, -1, 1, 1.5])
            elif r < 0.25:
                p_type = "trampoline" # 10%の確率で「バネ」
            elif r < 0.40:
                p_type = "fragile"    # 15%の確率で「ヒビ」
            elif r < 0.45:
                p_type = "spike"      #  5%の確率で「トゲ」
            elif r < 0.55:
                p_type = "conveyor"   # 10%の確率で「コンベア」
                vx = random.choice([-1.0, 1.0])
            # 残りの 45% は「通常の青ブロック」になります
            
        self.platforms.append({
            "rect": pygame.Rect(x, y, w, self.PLAT_H),
            "type": p_type,
            "vx": vx,
            "exact_x": float(x),
            "exact_y": float(y),
            "timer": 0,
            "stepped": False
        })

    async def run(self):
        while True:
            self.handle_events()
            if self.game_state == "PLAY":
                self.update()
            self.draw()
            self.clock.tick(60)
            await asyncio.sleep(0)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if self.game_state == "START":
                    if event.key == pygame.K_UP:
                        self.menu_index = (self.menu_index - 1) % len(self.menu_options)
                    elif event.key == pygame.K_DOWN:
                        self.menu_index = (self.menu_index + 1) % len(self.menu_options)
                    elif event.key == pygame.K_RETURN:
                        opt = self.menu_options[self.menu_index]
                        if opt == "スタート":
                            self.reset_game()
                        elif opt == "ランキング":
                            self.game_state = "RANKING"
                            asyncio.create_task(fetch_ranking())
                elif self.game_state == "GAMEOVER":
                    if event.key == pygame.K_RETURN:
                        self.game_state = "START"
                elif self.game_state == "RANKING":
                    if event.key == pygame.K_RETURN:
                        self.game_state = "START"

    def update(self):
        old_y = self.player_y
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.player_vx = -self.move_speed
        elif keys[pygame.K_RIGHT]:
            self.player_vx = self.move_speed
        else:
            self.player_vx = 0

        self.player_vy += self.gravity
        self.player_x += self.player_vx
        self.player_y += self.player_vy

        if self.player_x < 0: 
            self.player_x = 0
        if self.player_x > self.WIDTH - self.player_w: 
            self.player_x = self.WIDTH - self.player_w

        # 画面のスクロール速度（難易度）を徐々に上げる
        self.scroll_speed += 0.00035
        # スクロール速度の最大値を制限
        if self.scroll_speed > 1.3:
            self.scroll_speed = 1.3
        
        for p in self.platforms:
            p["exact_y"] -= self.scroll_speed
            p["rect"].y = int(p["exact_y"])
            if p["type"] == "moving":
                p["exact_x"] += p["vx"]
                p["rect"].x = int(p["exact_x"])
                if p["rect"].left < 0:
                    p["exact_x"] = 0
                    p["rect"].left = 0
                    p["vx"] *= -1
                elif p["rect"].right > self.WIDTH:
                    p["rect"].right = self.WIDTH
                    p["exact_x"] = self.WIDTH - p["rect"].width
                    p["vx"] *= -1

        for p in self.platforms:
            if p.get("type") == "fragile" and p.get("stepped"):
                p["timer"] += 1

        player_rect = pygame.Rect(int(self.player_x), int(self.player_y), self.player_w, self.player_h + 2)
        self.on_ground = False
        
        for p in self.platforms:
            r = p["rect"]
            
            if p.get("type") == "spike" and player_rect.colliderect(r):
                self.player_y = self.HEIGHT + 100 # Game Over
                continue
                
            if self.player_vy > 0 and player_rect.colliderect(r) and player_rect.bottom <= r.top + 10:
                if p["type"] == "trampoline":
                    if getattr(self, 'snd_bounce', None): self.snd_bounce.play()
                    self.player_y = r.top - self.player_h
                    # トランポリンの跳ねる力 (数値をマイナス方向に大きくすると高く跳ねる)
                    self.player_vy = -3.6
                    self.on_ground = False
                elif p["type"] == "fragile" and p.get("timer", 0) > 30:
                    # ヒビブロックに乗ってから壊れるまでの時間 (30を大きくすると長持ちする)
                    pass # Broken!
                else:
                    if self.player_vy > 0.5 and getattr(self, 'snd_land', None): 
                        self.snd_land.play()
                    self.player_y = r.top - self.player_h
                    self.player_vy = 0
                    self.player_y -= self.scroll_speed
                    if p["type"] == "moving":
                        self.player_x += p["vx"]
                    elif p["type"] == "conveyor":
                        # コンベアで流される速度の倍率 (1.5を大きくすると速く流される)
                        self.player_x += p["vx"] * 1.5
                    elif p["type"] == "fragile":
                        p["stepped"] = True
                    self.on_ground = True
                break

        self.platforms = [p for p in self.platforms if p["rect"].bottom > 18 and not (p.get("type") == "fragile" and p.get("timer", 0) > 30)] # ヘッダーに隠れたら、または壊れたら消す
        
        if len(self.platforms) == 0 or self.platforms[-1]["rect"].y < self.HEIGHT - 20:
            self.spawn_platform(self.HEIGHT + random.randint(4, 12))

        # キャラの絶対的な落下距離を計算
        delta_y = self.player_y - old_y
        self.current_fall_distance += delta_y + self.scroll_speed
        
        if self.current_fall_distance > self.max_fall_distance:
            self.max_fall_distance = self.current_fall_distance
            
        self.score = self.max_fall_distance * 0.1

        # 画面下、または上部のヘッダー(y=18)に接触したらゲームオーバー
        if self.player_y > self.HEIGHT or self.player_y <= 18:
            if self.game_state != "GAMEOVER":
                if getattr(self, 'snd_gameover', None): self.snd_gameover.play()
            self.game_state = "GAMEOVER"
            
            # ゲームオーバー時にオンラインスコアを送信
            if int(self.score) > 0:
                import datetime
                current_time = datetime.datetime.now().strftime("%Y/%m/%d %H:%M")
                asyncio.create_task(save_score(current_time, int(self.score)))

    def draw_retro_block(self, rect, base_color):
        pygame.draw.rect(self.display, base_color, rect)
        light = (min(255, base_color[0]+70), min(255, base_color[1]+70), min(255, base_color[2]+70))
        pygame.draw.line(self.display, light, (rect.left, rect.top), (rect.right-1, rect.top))
        pygame.draw.line(self.display, light, (rect.left, rect.top), (rect.left, rect.bottom-1))
        dark = (max(0, base_color[0]-70), max(0, base_color[1]-70), max(0, base_color[2]-70))
        pygame.draw.line(self.display, dark, (rect.left, rect.bottom-1), (rect.right-1, rect.bottom-1))
        pygame.draw.line(self.display, dark, (rect.right-1, rect.top), (rect.right-1, rect.bottom-1))

    def draw(self):
        self.display.fill(self.BLACK)
        
        if self.game_state == "START":
            title_text = self.big_font.render("無限落下", False, self.GREEN)
            self.display.blit(title_text, ((self.WIDTH//2)*2 - title_text.get_width()//2, (self.HEIGHT//2)*2 - 120))
            
            for i, opt in enumerate(self.menu_options):
                color = self.CYAN if i == self.menu_index else self.WHITE
                prefix = "> " if i == self.menu_index else "  "
                text = self.font.render(f"{prefix}{opt}", False, color)
                self.display.blit(text, ((self.WIDTH//2)*2 - 80, (self.HEIGHT//2)*2 + i * 40))
                
            guide_text = self.font.render("← → キーで移動", False, (150, 150, 150))
            self.display.blit(guide_text, ((self.WIDTH//2)*2 - guide_text.get_width()//2, self.HEIGHT * 2 - 100))
            
            guide_text2 = self.font.render("Enterキーで決定", False, (150, 150, 150))
            self.display.blit(guide_text2, ((self.WIDTH//2)*2 - guide_text2.get_width()//2, self.HEIGHT * 2 - 60))

        elif self.game_state == "RANKING":
            title_text = self.big_font.render("ランキング", False, self.GREEN)
            self.display.blit(title_text, ((self.WIDTH//2)*2 - title_text.get_width()//2, 40))
            
            if online_ranking_data is None:
                loading_text = self.font.render("Loading...", False, (150, 150, 150))
                self.display.blit(loading_text, ((self.WIDTH//2)*2 - loading_text.get_width()//2, 200))
            elif len(online_ranking_data) == 0:
                empty_text = self.font.render("まだ記録がありません", False, (150, 150, 150))
                self.display.blit(empty_text, ((self.WIDTH//2)*2 - empty_text.get_width()//2, 200))
            else:
                for i in range(10):
                    if i < len(online_ranking_data):
                        score_val = str(online_ranking_data[i].get('score', 0)) + "m"
                        name_val = str(online_ranking_data[i].get('name', ''))[:16]
                        # 順位、スコア、日付時間の順に配置
                        rank_text = self.font.render(f"{i+1:2d}位 {score_val.rjust(6)} {name_val}", False, self.WHITE)
                    else:
                        rank_text = self.font.render(f"{i+1:2d}位 ------ ----------------", False, (100, 100, 100))
                    
                    # 画面幅(480)の中央から少し左寄りに配置
                    self.display.blit(rank_text, ((self.WIDTH//2)*2 - 190, 120 + i * 32))
                
            back_text = self.font.render("PUSH ENTER", False, self.CYAN)
            self.display.blit(back_text, ((self.WIDTH//2)*2 - back_text.get_width()//2, 560))

        elif self.game_state == "PLAY" or self.game_state == "GAMEOVER":
            for p in self.platforms:
                r = p["rect"]
                
                # 点滅時の描画スキップ (割れるブロック)
                if p["type"] == "fragile" and p.get("stepped") and (p.get("timer", 0) // 4) % 2 == 0:
                    continue
                    
                # ブロックの画像タイプを判定
                block_key = p["type"]
                if block_key == "moving":
                    block_key = "normal"
                elif block_key == "conveyor":
                    if p.get("vx", 1) > 0:
                        block_key = "conveyor_right"
                    else:
                        block_key = "conveyor_left"
                        
                img = self.img_blocks.get(block_key, self.img_blocks["normal"])
                
                # 16x16の画像を横幅分敷き詰める (論理座標を2倍)
                for x in range(r.left, r.right, 8):
                    self.display.blit(img, (x * 2, r.top * 2))

            
            if self.game_state == "PLAY":
                if self.player_vy > 0.5 and not self.on_ground:
                    self.display.blit(self.img_fall, (int(self.player_x * 2), int(self.player_y * 2)))
                elif self.player_vx < 0:
                    self.display.blit(self.img_left, (int(self.player_x * 2), int(self.player_y * 2)))
                elif self.player_vx > 0:
                    self.display.blit(self.img_right, (int(self.player_x * 2), int(self.player_y * 2)))
                else:
                    self.display.blit(self.img_stand, (int(self.player_x * 2), int(self.player_y * 2)))
                
                # iアプリ風のステータスヘッダーバー
                pygame.draw.rect(self.display, (40, 40, 80), (0, 0, self.WIDTH * 2, 36))
                pygame.draw.line(self.display, self.WHITE, (0, 36), (self.WIDTH * 2, 36))
                
                # 天井のデッドラインを示すトゲを反転して描画
                ceiling_spike = pygame.transform.flip(self.img_blocks["spike"], False, True)
                for x in range(0, self.WIDTH, 8):
                    self.display.blit(ceiling_spike, (x * 2, 37))
                
                score_text = self.font.render(f"記録:{int(self.score)}m", False, self.WHITE)
                self.display.blit(score_text, (8, 4))
                
                # レベル表示
                if self.score >= 800:
                    level_str = "レベル:3"
                elif self.score >= 400:
                    level_str = "レベル:2"
                else:
                    level_str = "レベル:1"
                level_text = self.font.render(level_str, False, self.WHITE)
                self.display.blit(level_text, (self.WIDTH * 2 - level_text.get_width() - 8, 4))
                
            elif self.game_state == "GAMEOVER":
                # ヘッダーは残す
                pygame.draw.rect(self.display, (40, 40, 80), (0, 0, self.WIDTH * 2, 36))
                pygame.draw.line(self.display, self.WHITE, (0, 36), (self.WIDTH * 2, 36))
                
                ceiling_spike = pygame.transform.flip(self.img_blocks["spike"], False, True)
                for x in range(0, self.WIDTH, 8):
                    self.display.blit(ceiling_spike, (x * 2, 37))
                
                dialog_w, dialog_h = 320, 180
                dialog_rect = pygame.Rect((self.WIDTH//2)*2 - dialog_w//2, (self.HEIGHT//2)*2 - dialog_h//2, dialog_w, dialog_h)
                
                pygame.draw.rect(self.display, (0, 0, 60), dialog_rect)
                pygame.draw.rect(self.display, self.WHITE, dialog_rect, 4)
                pygame.draw.rect(self.display, (150, 150, 200), dialog_rect.inflate(-8, -8), 2)
                
                go_text = self.big_font.render("終了", False, self.WHITE)
                self.display.blit(go_text, ((self.WIDTH//2)*2 - go_text.get_width()//2, (self.HEIGHT//2)*2 - 60))
                
                score_text = self.font.render(f"記録: {int(self.score)}m", False, self.WHITE)
                self.display.blit(score_text, ((self.WIDTH//2)*2 - score_text.get_width()//2, (self.HEIGHT//2)*2))
                
                if pygame.time.get_ticks() % 1000 < 500:
                    retry_text = self.font.render("PUSH ENTER KEY", False, self.CYAN)
                    self.display.blit(retry_text, ((self.WIDTH//2)*2 - retry_text.get_width()//2, (self.HEIGHT//2)*2 + 50))

        # 最後に小さいSurfaceを引き伸ばしてメイン画面に描画
        scaled = pygame.transform.scale(self.display, (self.WINDOW_W, self.WINDOW_H))
        self.screen.blit(scaled, (0, 0))
        pygame.display.flip()

async def main():
    game = DropManGame()
    await game.run()

if __name__ == "__main__":
    asyncio.run(main())
