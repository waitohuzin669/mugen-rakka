"""16x16 ドット絵ブロック画像を生成するスクリプト。
W=メイン / B=黒枠 / G=影 / T=透明
"""
import os
import pygame

PALETTES = {
    # 形式: (メイン色W, 影色G) - ゲームボーイカラー風 パステル＆ハイコントラスト
    "blocks_normal.png":  (( 40, 120, 248, 255), (  0,  64, 192, 255)), # 普通の青色 / 濃い青
    "blocks_spike.png":   ((248,  56,   0, 255), (168,   0,  32, 255)), # 普通の赤（マリオレッド） / 濃い赤
    "blocks_broken.png":  ((188, 188, 188, 255), (116, 116, 116, 255)), # 普通の石色（グレー）
    "blocks_spring.png":  ((136, 228,   0, 255), (  0, 168,   0, 255)), # 普通の緑（土管グリーン）
    "blocks_right.png":   ((248, 184,   0, 255), (172, 124,   0, 255)), # 普通の黄色（コインイエロー）
    "blocks_left.png":    ((248, 184,   0, 255), (172, 124,   0, 255)), # 普通の黄色（コインイエロー）
}

BLOCKS = {
    # 1. 通常ブロック (右下影で立体化)
    "blocks_normal.png": [
        "BBBBBBBBBBBBBBBB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BGGGGGGGGGGGGGGB",
        "BGGGGGGGGGGGGGGB",
        "BBBBBBBBBBBBBBBB",
    ],
    # 2. トゲブロック (毒々しい紫)
    "blocks_spike.png": [
        "TTTTTTTBBTTTTTTT",
        "TTTTTTTBBTTTTTTT",
        "TTTTTTBWGBTTTTTT",
        "TTTTTTBWGBTTTTTT",
        "TTTTTBWWGGBTTTTT",
        "TTTTTBWWGGBTTTTT",
        "TTTTBWWWGGGBTTTT",
        "TTTTBWWWGGGBTTTT",
        "TTTBWWWWGGGGBTTT",
        "TTTBWWWWGGGGBTTT",
        "TTBWWWWWGGGGGBTT",
        "TTBWWWWWGGGGGBTT",
        "TBWWWWWWGGGGGGBT",
        "TBWWWWWWGGGGGGBT",
        "BWWWWWWWGGGGGGGB",
        "BBBBBBBBBBBBBBBB",
    ],
    # 3. ヒビブロック (右下影)
    "blocks_broken.png": [
        "BBBBBBBBBBBBBBBB",
        "BWWWWWWBWWWWWGGB",
        "BWWWWWWBWWWWWGGB",
        "BWWWWWBWWWWWWGGB",
        "BWWWWWBWWWWWWGGB",
        "BWWWWBWWWWWWWGGB",
        "BWWWWBBBWWWWWGGB",
        "BWWWWWWWBWWWWGGB",
        "BWWWWWWWBWWWWGGB",
        "BWWWWWWBWWWWWGGB",
        "BWWWWWWBWWWWWGGB",
        "BWWWWWBWWWWWWGGB",
        "BWWWWWBWWWWWWGGB",
        "BGGGGGBGGGGGGGGB",
        "BGGGGGBGGGGGGGGB",
        "BBBBBBBBBBBBBBBB",
    ],
    # 4. バネブロック (右側グラデーション影)
    "blocks_spring.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TBBBBBBBBBBBBBBT",
        "TBWWWWWWWGGGGGBT",
        "TBWWWWWGGGGGGGBT",
        "TBBBBBBBBBBBBBBT",
        "TTTBWGBTTBWGBTTT",
        "TTBWGBTTBWGBTTTT",
        "TTTBWGBTTBWGBTTT",
        "TTBWGBTTBWGBTTTT",
        "TTTBWGBTTBWGBTTT",
        "TTBWGBTTBWGBTTTT",
        "TTBBBBBBBBBBBBTT",
        "TBWWWWWWWGGGGGBT",
        "TBBBBBBBBBBBBBBT",
    ],
    # 5. コンベア右 (影なし平面版)
    "blocks_right.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TBBBBBBBBBBBBBBT",
        "BWWWWWWWWWWWWWWB",
        "BWWBBWWWWBBWWWWB",
        "BWWWBBWWWWBBWWWB",
        "BWWWWBBWWWWBBWWB",
        "BWWWBBWWWWBBWWWB",
        "BWWBBWWWWBBWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BGGGGGGGGGGGGGGB",
        "TBBBBBBBBBBBBBBT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
    # 6. コンベア左 (影なし平面版)
    "blocks_left.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TBBBBBBBBBBBBBBT",
        "BWWWWWWWWWWWWWWB",
        "BWWWWBBWWWWBBWWB",
        "BWWWBBWWWWBBWWWB",
        "BWWBBWWWWBBWWWWB",
        "BWWWBBWWWWBBWWWB",
        "BWWWWBBWWWWBBWWB",
        "BWWWWWWWWWWWWWWB",
        "BGGGGGGGGGGGGGGB",
        "TBBBBBBBBBBBBBBT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
}

def save_block(path, name, grid):
    assert len(grid) == 16 and all(len(r) == 16 for r in grid), path
    color_w, color_g = PALETTES[name]
    
    img = pygame.Surface((16, 16), pygame.SRCALPHA)
    for y, row in enumerate(grid):
        for x, c in enumerate(row):
            if c == "W":
                rgba = color_w
            elif c == "G":
                rgba = color_g
            elif c == "B":
                rgba = (0, 0, 0, 255) # 真っ黒
            elif c == "T":
                rgba = (0, 0, 0, 0)
            img.set_at((x, y), rgba)
    pygame.image.save(img, path)

if __name__ == "__main__":
    pygame.init()
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
    os.makedirs(out_dir, exist_ok=True)
    for name, grid in BLOCKS.items():
        save_block(os.path.join(out_dir, name), name, grid)
        print("saved", name)
