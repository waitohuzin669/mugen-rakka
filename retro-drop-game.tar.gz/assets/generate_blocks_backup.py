"""16x16 ドット絵ブロック画像を生成するスクリプト。
W=メイン / B=黒枠 / G=影 / T=透明
"""
import os
import pygame

PALETTES = {
    # 形式: (メイン色W, 影色G)
    "blocks_normal.png":  (( 30,  80, 220, 255), ( 10,  40, 150, 255)), # 青
    "blocks_spike.png":   ((255, 120, 120, 255), (180,  50,  50, 255)), # 赤 (危険)
    "blocks_broken.png":  ((160, 160, 160, 255), (100, 100, 100, 255)), # 灰色 (ヒビ)
    "blocks_spring.png":  ((120, 240, 120, 255), ( 60, 170,  60, 255)), # 緑 (ジャンプ)
    "blocks_right.png":   ((255, 220,  80, 255), (180, 140,  40, 255)), # 黄 (ギミック)
    "blocks_left.png":    ((255, 220,  80, 255), (180, 140,  40, 255)), # 黄 (ギミック)
}

BLOCKS = {
    # 1. 通常ブロック
    "blocks_normal.png": [
        "BBBBBBBBBBBBBBBB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BGGGGGGGGGGGGGGB",
        "BGGGGGGGGGGGGGGB",
        "BBBBBBBBBBBBBBBB",
    ],
    # 2. トゲブロック
    "blocks_spike.png": [
        "TTTTTTTBBTTTTTTT",
        "TTTTTTTBBTTTTTTT",
        "TTTTTTBWGBTTTTTT",
        "TTTTTTBWGBTTTTTT",
        "TTTTTBWWGGBTTTTT",
        "TTTTTBWWGGBTTTTT",
        "TTTTBWWWGGGBTTTT",
        "TTTTBWWWGGGBTTTT",
        "TTTBWWWWGGGGBTTT",
        "TTTBWWWWGGGGBTTT",
        "TTBWWWWWGGGGGBTT",
        "TTBWWWWWGGGGGBTT",
        "TBWWWWWWGGGGGGBT",
        "TBWWWWWWGGGGGGBT",
        "BWWWWWWWGGGGGGGB",
        "BBBBBBBBBBBBBBBB",
    ],
    # 3. ヒビブロック
    "blocks_broken.png": [
        "BBBBBBBBBBBBBBBB",
        "BWWWWWWBWWWWWWWB",
        "BWWWWWWBWWWWWWWB",
        "BWWWWWBWWWWWWWWB",
        "BWWWWWBWWWWWWWWB",
        "BWWWWBWWWWWWWWWB",
        "BWWWWBBBWWWWWWWB",
        "BWWWWWWWBWWWWWWB",
        "BWWWWWWWBWWWWWWB",
        "BWWWWWWBWWWWWWWB",
        "BWWWWWWBWWWWWWWB",
        "BWWWWWBWWWWWWWWB",
        "BWWWWWBWWWWWWWWB",
        "BGGGGGBGGGGGGGGB",
        "BGGGGGBGGGGGGGGB",
        "BBBBBBBBBBBBBBBB",
    ],
    # 4. バネブロック (ダブルスプリング・平らなクッション)
    "blocks_spring.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TBBBBBBBBBBBBBBT",
        "TBWWWWWWWWWWWWBT",
        "TBGGGGGGGGGGGGBT",
        "TBBBBBBBBBBBBBBT",
        "TTTBWGBTTBWGBTTT",
        "TTBWGBTTBWGBTTTT",
        "TTTBWGBTTBWGBTTT",
        "TTBWGBTTBWGBTTTT",
        "TTTBWGBTTBWGBTTT",
        "TTBWGBTTBWGBTTTT",
        "TTBBBBBBBBBBBBTT",
        "TBWWGGGGGGGGWWBT",
        "TBBBBBBBBBBBBBBT",
    ],
    # 5. コンベア右 (ホバーボード風シルエット・太模様)
    "blocks_right.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TBBBBBBBBBBBBBBT",
        "BWWWWWWWWWWWWWWB",
        "BWWBBWWWWBBWWWWB",
        "BWWWBBWWWWBBWWWB",
        "BWWWWBBWWWWBBWWB",
        "BWWWBBWWWWBBWWWB",
        "BWWBBWWWWBBWWWWB",
        "BWWWWWWWWWWWWWWB",
        "BGGGGGGGGGGGGGGB",
        "TBBBBBBBBBBBBBBT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
    # 6. コンベア左 (ホバーボード風シルエット・太模様)
    "blocks_left.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TBBBBBBBBBBBBBBT",
        "BWWWWWWWWWWWWWWB",
        "BWWWWBBWWWWBBWWB",
        "BWWWBBWWWWBBWWWB",
        "BWWBBWWWWBBWWWWB",
        "BWWWBBWWWWBBWWWB",
        "BWWWWBBWWWWBBWWB",
        "BWWWWWWWWWWWWWWB",
        "BGGGGGGGGGGGGGGB",
        "TBBBBBBBBBBBBBBT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
}

def save_block(path, name, grid):
    assert len(grid) == 16 and all(len(r) == 16 for r in grid), path
    color_w, color_g = PALETTES[name]
    
    img = pygame.Surface((16, 16), pygame.SRCALPHA)
    for y, row in enumerate(grid):
        for x, c in enumerate(row):
            if c == "W":
                rgba = color_w
            elif c == "G":
                rgba = color_g
            elif c == "B":
                rgba = (0, 0, 0, 255)
            elif c == "T":
                rgba = (0, 0, 0, 0)
            img.set_at((x, y), rgba)
    pygame.image.save(img, path)

if __name__ == "__main__":
    pygame.init()
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
    os.makedirs(out_dir, exist_ok=True)
    for name, grid in BLOCKS.items():
        save_block(os.path.join(out_dir, name), name, grid)
        print("saved", name)
