import os
import pygame

PALETTES = {
    "test_blocks_broken.png":  ((160, 160, 160, 255), (100, 100, 100, 255)),
    "test_blocks_spring.png":  ((120, 240, 120, 255), ( 60, 170,  60, 255)),
    "test_blocks_right.png":   ((255, 220,  80, 255), (180, 140,  40, 255)),
    "test_blocks_left.png":    ((255, 220,  80, 255), (180, 140,  40, 255)),
}

BLOCKS = {
    "test_blocks_broken.png": [
        "TTTBBBBBBBBBBTTT",
        "TTBWWWWWWWWGGBTT",
        "TBWWWWWBBWWWGGBB",
        "BWWWWWBTTBWWWGGB",
        "BWWWWWBTTBWWWGGB",
        "BWWWWWBBBBWWWGGB",
        "BWWWWWWWWWWWWGGB",
        "BWWWWWBBBBWWWGGB",
        "BBWWWBTTTBWWWGGB",
        "TBWWWBTTTBWWWGGB",
        "TBWWWWBBBBWWWGGB",
        "TBWWWWWWWWWWWGGB",
        "TTBWWWWWWWWWGGBB",
        "TTTBBGGGGGGGBBTT",
        "TTTTTBBBBBBBTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
    "test_blocks_spring.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTBBBBBBBBBBTTT",
        "TTBWWWWWWWWWWBTT",
        "TTBBBBBBBBBBBBTT",
        "TTTTTBBBBBBTTTTT",
        "TTTTTBWWGGBTTTTT",
        "TTTTTBBWWGBTTTTT",
        "TTTTTBGWWBBTTTTT",
        "TTTTTBWWGGBTTTTT",
        "TTTTTBBWWGBTTTTT",
        "TTTTTBGWWBBTTTTT",
        "TTTTTBBBBBBTTTTT",
        "TTTBBBBBBBBBBTTT",
        "TTBGGGGGGGGGGBTT",
        "TTBBBBBBBBBBBBTT",
    ],
    "test_blocks_right.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TBBBBBBBBBBBBBBT",
        "BWWWWWWWWWWWWWWB",
        "BWBBWWBBWWBBWWBB",
        "BWTBWBWTBWBWTBWB",
        "BWBBWWBBWWBBWWBB",
        "BWTBWBWTBWBWTBWB",
        "BWBBWWBBWWBBWWBB",
        "BWTBWBWTBWBWTBWB",
        "BWBBWWBBWWBBWWBB",
        "BGGGGGGGGGGGGGGB",
        "TBBBBBBBBBBBBBBT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
    "test_blocks_left.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TBBBBBBBBBBBBBBT",
        "BWWWWWWWWWWWWWWB",
        "BWWBBWWBBWWBBWWB",
        "BWTBWBWTBWBWTBWB",
        "BWWBBWWBBWWBBWWB",
        "BWTBWBWTBWBWTBWB",
        "BWWBBWWBBWWBBWWB",
        "BWTBWBWTBWBWTBWB",
        "BWWBBWWBBWWBBWWB",
        "BGGGGGGGGGGGGGGB",
        "TBBBBBBBBBBBBBBT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
}

def save_block(path, name, grid):
    assert len(grid) == 16 and all(len(r) == 16 for r in grid), f"{name} is not 16x16"
    color_w, color_g = PALETTES[name]
    
    img = pygame.Surface((16, 16), pygame.SRCALPHA)
    for y, row in enumerate(grid):
        for x, c in enumerate(row):
            if c == "W":
                rgba = color_w
            elif c == "G":
                rgba = color_g
            elif c == "B":
                rgba = (0, 0, 0, 255)
            elif c == "T":
                rgba = (0, 0, 0, 0)
            img.set_at((x, y), rgba)
    pygame.image.save(img, path)

if __name__ == "__main__":
    pygame.init()
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_assets")
    os.makedirs(out_dir, exist_ok=True)
    for name, grid in BLOCKS.items():
        save_block(os.path.join(out_dir, name), name, grid)
        print("saved", name)
