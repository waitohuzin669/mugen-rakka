import json

for filename in ['C:/Users/shima/.gemini/antigravity-ide/brain/c432181d-6f94-4f3d-ba55-6b525e1d85a4/.system_generated/logs/transcript_full.jsonl']:
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            if 'mugen-rakka' in line.lower():
                data = json.loads(line)
                idx = data.get('step_index', 0)
                if 'content' in data:
                    print(f"STEP {idx} TYPE {data.get('type')}: {data['content'][:200]}")
                elif 'tool_calls' in data:
                    print(f"STEP {idx} TOOL CALLS: {data['tool_calls']}")
