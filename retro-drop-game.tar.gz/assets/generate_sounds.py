import wave
import struct
import math
import random
import os

def create_wav(filename, num_samples, sample_rate, callback):
    with wave.open(filename, 'w') as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2) # 16-bit
        wav_file.setframerate(sample_rate)
        
        for i in range(num_samples):
            t = i / sample_rate
            val = callback(t, i)
            val = max(-1.0, min(1.0, val))
            data = struct.pack('<h', int(val * 32767))
            wav_file.writeframesraw(data)

os.makedirs("assets", exist_ok=True)
sr = 44100

# 1. Land (控えめな「タッ」)
def land_cb(t, i):
    env = max(0, 1.0 - (t / 0.05)) # 50ms long
    noise = random.uniform(-1.0, 1.0)
    return noise * env * 0.15  # 音量かなり控えめ

create_wav('assets/land.wav', int(sr * 0.05), sr, land_cb)

# 2. Bounce (トランポリン「ピョーン」)
def bounce_cb(t, i):
    env = max(0, 1.0 - (t / 0.25))
    # ピッチが急激に上がる矩形波
    freq = 300 + (t / 0.25) * 600
    phase = 2 * math.pi * freq * t
    val = 1.0 if math.sin(phase) > 0 else -1.0
    return val * env * 0.3

create_wav('assets/bounce.wav', int(sr * 0.25), sr, bounce_cb)

# 3. Game Over (下降する「ピューン…」)
def gameover_cb(t, i):
    env = max(0, 1.0 - (t / 0.8))
    # ピッチが下がる矩形波
    freq = 600 - (t / 0.8) * 450
    phase = 2 * math.pi * freq * t
    val = 1.0 if math.sin(phase) > 0 else -1.0
    return val * env * 0.4

create_wav('assets/gameover.wav', int(sr * 0.8), sr, gameover_cb)

print("Sounds generated successfully!")
