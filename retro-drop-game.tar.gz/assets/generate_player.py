import os
import pygame

PLAYER_SPRITES = {
    "player_stand.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTWWWWTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTWWWWTTTTTT",
        "TTTTTWTWWTWTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTWWWWTTTTTT",
        "TTTTTTWTTWTTTTTT",
        "TTTTTTWTTWTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
    "player_left.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTWWWWTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTWWWWWTTTTT",
        "TTTTTWTWWTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTWWTWWTTTTTTT",
        "TTTTTTWTTWTTTTTT",
        "TTTTTTTTTTWTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
    "player_right.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTWWWWTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTWWWWWTTTTTT",
        "TTTTTTTWWTWTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTTWWTWWTTTT",
        "TTTTTTWTTWTTTTTT",
        "TTTTTWTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
    "player_fall.png": [
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTWTWWTWTTTTT",
        "TTTTTWWWWWWTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTTWWTTTTTTT",
        "TTTTTTWTTWTTTTTT",
        "TTTTTWTTTTWTTTTT",
        "TTTTTWTTTTWTTTTT",
        "TTTTTTTTTTTTTTTT",
        "TTTTTTTTTTTTTTTT",
    ],
}

def save_sprite(path, grid):
    assert len(grid) == 16 and all(len(r) == 16 for r in grid), path
    img = pygame.Surface((16, 16), pygame.SRCALPHA)
    for y, row in enumerate(grid):
        for x, c in enumerate(row):
            if c == "W":
                rgba = (252, 252, 252, 255) # ピュアな白
            elif c == "B":
                rgba = (0, 0, 0, 255) # 真っ黒
            elif c == "T":
                rgba = (0, 0, 0, 0)
            img.set_at((x, y), rgba)
    pygame.image.save(img, path)

if __name__ == "__main__":
    pygame.init()
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
    os.makedirs(out_dir, exist_ok=True)
    for name, grid in PLAYER_SPRITES.items():
        save_sprite(os.path.join(out_dir, name), grid)
        print("saved", name)
